import pytest
import tableCreation

pytestmark = pytest.mark.usefixtures("spark_session")

def test_tablecreation(spark_session):
	"""sql_query=
	drop table if EXISTSdefault.testing_pytest;
	CREATE TABLE IF NOT EXISTS default.testing_pytest ( id int, name String,
	company String)
	ROW FORMAT DELIMITED
	FIELDS TERMINATED BY '\t'
	LINES TERMINATED BY '\n'
	STORED AS TEXTFILE
	"""
	tab_name="testing_pytest"
	db_name="default"
	results = tableCreation.table_creation(spark_session,tab_name,db_name)
	expected_results = ['id', 'name', 'company']
	assert sorted(results) == sorted(expected_results)
