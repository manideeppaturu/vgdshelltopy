def table_creation(spark,table_name,db_name):
	try:
		#spark.sql(sql_qery)
		table_df=spark.sql("select * from "+db_name+"."+table_name)
		return table_df.columns
	except:
		print("Failed while creation Table")
